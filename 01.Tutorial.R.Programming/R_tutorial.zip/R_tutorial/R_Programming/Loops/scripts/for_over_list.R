# You're about to write two for-loops that loop over a list using both methods of access: by element and by position of the element in the list! Remember to use double-quotes when accessing list elements by their position number! 

# Save the script before typing submit() in the console after you edit it.

for_over_list<- function(n=2) {

  my_list <- list(c(1:n), rep(1,n))

  sum_by_element <- 0
  sum_by_position <- 0

  # Code the for-loop that sums by element
    

  # Code the for-loop that sums by position number
  

  # Return the resulting sums as a named list
  list(element=sum_by_element, position=sum_by_position)
  
}
