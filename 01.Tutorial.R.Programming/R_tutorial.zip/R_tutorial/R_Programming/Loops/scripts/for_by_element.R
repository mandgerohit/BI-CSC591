# You're about to write for-loop in R that accesses a sequence by element! 

# Save the script before typing submit() in the console after you edit it.

for_by_element <- function(n=3) {
  my_sequence <- c(1:n)
  msg<-""
  # Code the for-loop construct
    
  # Return the resulting msg
   
}
