# You're about to write control actions inside else-if-else statements in R! 

# Save the script before typing submit() in the console after you edit it.

control_actions <- function(li, fb) {
  
  # Code the control-flow construct

  
  # Return the resulting sms 
 
  
}
